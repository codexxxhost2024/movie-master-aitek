/**
 * Download Manager for Panyero
 * Handles downloading movies and TV shows for offline viewing
 */

class DownloadManager {
  constructor() {
    this.dbName = "downloads-db"
    this.dbVersion = 1
    this.db = null
    this.isInitialized = false
    this.downloadQueue = []
    this.activeDownloads = 0
    this.maxConcurrentDownloads = 2
    this.listeners = {}

    // Initialize the database
    this.init()

    // Listen for service worker messages
    if ("serviceWorker" in navigator && navigator.serviceWorker.controller) {
      navigator.serviceWorker.addEventListener("message", this.handleServiceWorkerMessage.bind(this))
    }
  }

  /**
   * Initialize the download manager
   */
  async init() {
    try {
      // Open IndexedDB
      const db = await this.openDatabase()
      this.db = db
      this.isInitialized = true

      // Process any pending downloads in the queue
      this.processQueue()

      // Register for background sync if available
      this.registerBackgroundSync()

      console.log("Download Manager initialized successfully")
    } catch (error) {
      console.error("Failed to initialize Download Manager:", error)
    }
  }

  /**
   * Open the IndexedDB database
   */
  openDatabase() {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(this.dbName, this.dbVersion)

      request.onerror = (event) => {
        console.error("Failed to open database:", event.target.error)
        reject(event.target.error)
      }

      request.onsuccess = (event) => {
        const db = event.target.result
        resolve(db)
      }

      request.onupgradeneeded = (event) => {
        const db = event.target.result

        // Create object stores if they don't exist
        if (!db.objectStoreNames.contains("pending")) {
          const pendingStore = db.createObjectStore("pending", { keyPath: "id" })
          pendingStore.createIndex("status", "status", { unique: false })
          pendingStore.createIndex("addedAt", "addedAt", { unique: false })
        }

        if (!db.objectStoreNames.contains("completed")) {
          const completedStore = db.createObjectStore("completed", { keyPath: "id" })
          completedStore.createIndex("downloadedAt", "downloadedAt", { unique: false })
          completedStore.createIndex("type", "type", { unique: false })
        }
      }
    })
  }

  /**
   * Register for background sync
   */
  async registerBackgroundSync() {
    if ("serviceWorker" in navigator && "SyncManager" in window) {
      try {
        const registration = await navigator.serviceWorker.ready
        await registration.sync.register("sync-pending-downloads")
        console.log("Background sync registered")
      } catch (error) {
        console.error("Failed to register background sync:", error)
      }
    }
  }

  /**
   * Handle messages from the service worker
   */
  handleServiceWorkerMessage(event) {
    const { data } = event

    if (data.type === "download-complete") {
      this.emit("download-complete", { id: data.id })
      this.activeDownloads--
      this.processQueue()
    } else if (data.type === "download-failed") {
      this.emit("download-failed", { id: data.id, error: data.error })
      this.activeDownloads--
      this.processQueue()
    } else if (data.type === "download-progress") {
      this.emit("download-progress", {
        id: data.id,
        progress: data.progress,
        downloaded: data.downloaded,
        total: data.total,
      })
    }
  }

  /**
   * Add a download to the queue
   * @param {Object} item - The item to download
   * @param {string} item.id - Unique identifier for the download
   * @param {string} item.title - Title of the content
   * @param {string} item.url - URL to download from
   * @param {string} item.type - Type of content (movie, tv, music)
   * @param {number} item.size - Size of the content in bytes
   * @param {string} item.posterPath - Path to the poster image
   */
  async addToQueue(item) {
    if (!this.isInitialized) {
      // Queue the download for when the manager is initialized
      this.downloadQueue.push(item)
      return
    }

    try {
      // Check if the item is already in the queue or completed
      const existingPending = await this.getItem("pending", item.id)
      const existingCompleted = await this.getItem("completed", item.id)

      if (existingPending) {
        console.log(`Item ${item.id} is already in the download queue`)
        return existingPending
      }

      if (existingCompleted) {
        console.log(`Item ${item.id} is already downloaded`)
        return existingCompleted
      }

      // Add to pending downloads
      const downloadItem = {
        ...item,
        status: "pending",
        addedAt: Date.now(),
        progress: 0,
      }

      await this.addItem("pending", downloadItem)

      // Emit event
      this.emit("download-added", downloadItem)

      // Process the queue
      this.processQueue()

      return downloadItem
    } catch (error) {
      console.error("Failed to add download to queue:", error)
      throw error
    }
  }

  /**
   * Process the download queue
   */
  async processQueue() {
    if (!this.isInitialized || this.activeDownloads >= this.maxConcurrentDownloads) {
      return
    }

    try {
      // Get pending downloads
      const pendingDownloads = await this.getAllItems("pending")

      // Sort by added time (oldest first)
      pendingDownloads.sort((a, b) => a.addedAt - b.addedAt)

      // Filter for pending status
      const waitingDownloads = pendingDownloads.filter((item) => item.status === "pending")

      if (waitingDownloads.length === 0) {
        return
      }

      // Start downloading the next item
      const nextDownload = waitingDownloads[0]
      this.startDownload(nextDownload)
    } catch (error) {
      console.error("Failed to process download queue:", error)
    }
  }

  /**
   * Start downloading an item
   * @param {Object} item - The item to download
   */
  async startDownload(item) {
    try {
      // Update status to downloading
      await this.updateItem("pending", {
        ...item,
        status: "downloading",
        startedAt: Date.now(),
      })

      this.activeDownloads++

      // Emit event
      this.emit("download-started", item)

      // Check if Background Fetch API is supported
      if ("BackgroundFetchManager" in self && navigator.serviceWorker.controller) {
        const registration = await navigator.serviceWorker.ready

        // Start background fetch
        const bgFetch = await registration.backgroundFetch.fetch(`download-${item.id}`, [item.url], {
          title: `Downloading ${item.title}`,
          icons: [
            {
              sizes: "192x192",
              src: "/assets/images/icons/icon-192x192.png",
              type: "image/png",
            },
          ],
          downloadTotal: item.size || 50 * 1024 * 1024, // Default to 50MB if size unknown
        })

        // Update with background fetch ID
        await this.updateItem("pending", {
          ...item,
          status: "downloading",
          bgFetchId: bgFetch.id,
        })

        // Monitor progress
        bgFetch.addEventListener("progress", async (event) => {
          const progress = (event.downloaded / event.downloadTotal) * 100

          // Update progress
          await this.updateItem("pending", {
            ...item,
            status: "downloading",
            progress: Math.round(progress),
            downloaded: event.downloaded,
            total: event.downloadTotal,
          })

          // Emit progress event
          this.emit("download-progress", {
            id: item.id,
            progress: Math.round(progress),
            downloaded: event.downloaded,
            total: event.downloadTotal,
          })
        })
      } else {
        // Fallback for browsers without background fetch
        this.fallbackDownload(item)
      }
    } catch (error) {
      console.error(`Failed to start download for ${item.title}:`, error)

      // Update status to failed
      await this.updateItem("pending", {
        ...item,
        status: "failed",
        error: error.message,
      })

      // Emit event
      this.emit("download-failed", {
        id: item.id,
        error: error.message,
      })

      this.activeDownloads--
      this.processQueue()
    }
  }

  /**
   * Fallback download method for browsers without Background Fetch API
   * @param {Object} item - The item to download
   */
  async fallbackDownload(item) {
    try {
      // Create a fetch request
      const response = await fetch(item.url)

      if (!response.ok) {
        throw new Error(`Failed to download: ${response.statusText}`)
      }

      // Get content length
      const contentLength = response.headers.get("content-length")
      const total = contentLength ? Number.parseInt(contentLength, 10) : 0

      // Create a reader for the response body
      const reader = response.body.getReader()

      // Create a new response from the body
      let receivedLength = 0
      const chunks = []

      // Process the data
      while (true) {
        const { done, value } = await reader.read()

        if (done) {
          break
        }

        chunks.push(value)
        receivedLength += value.length

        // Calculate progress
        if (total > 0) {
          const progress = Math.round((receivedLength / total) * 100)

          // Update progress
          await this.updateItem("pending", {
            ...item,
            status: "downloading",
            progress: progress,
            downloaded: receivedLength,
            total: total,
          })

          // Emit progress event
          this.emit("download-progress", {
            id: item.id,
            progress: progress,
            downloaded: receivedLength,
            total: total,
          })
        }
      }

      // Concatenate chunks into a single Uint8Array
      const chunksAll = new Uint8Array(receivedLength)
      let position = 0
      for (const chunk of chunks) {
        chunksAll.set(chunk, position)
        position += chunk.length
      }

      // Create a blob from the data
      const blob = new Blob([chunksAll])

      // Store in cache
      const cache = await caches.open("downloads")
      await cache.put(`/downloads/${item.id}`, new Response(blob))

      // Move from pending to completed
      await this.deleteItem("pending", item.id)
      await this.addItem("completed", {
        ...item,
        status: "completed",
        downloadedAt: Date.now(),
        size: receivedLength,
      })

      // Emit event
      this.emit("download-complete", { id: item.id })

      this.activeDownloads--
      this.processQueue()
    } catch (error) {
      console.error(`Fallback download failed for ${item.title}:`, error)

      // Update status to failed
      await this.updateItem("pending", {
        ...item,
        status: "failed",
        error: error.message,
      })

      // Emit event
      this.emit("download-failed", {
        id: item.id,
        error: error.message,
      })

      this.activeDownloads--
      this.processQueue()
    }
  }

  /**
   * Cancel a download
   * @param {string} id - ID of the download to cancel
   */
  async cancelDownload(id) {
    try {
      const item = await this.getItem("pending", id)

      if (!item) {
        console.log(`Download ${id} not found`)
        return
      }

      // If using Background Fetch API
      if (item.bgFetchId && "BackgroundFetchManager" in self && navigator.serviceWorker.controller) {
        const registration = await navigator.serviceWorker.ready
        const bgFetch = await registration.backgroundFetch.get(item.bgFetchId)

        if (bgFetch) {
          await bgFetch.abort()
        }
      }

      // Remove from pending downloads
      await this.deleteItem("pending", id)

      // Emit event
      this.emit("download-cancelled", { id })

      if (item.status === "downloading") {
        this.activeDownloads--
        this.processQueue()
      }
    } catch (error) {
      console.error(`Failed to cancel download ${id}:`, error)
      throw error
    }
  }

  /**
   * Delete a downloaded item
   * @param {string} id - ID of the download to delete
   */
  async deleteDownload(id) {
    try {
      // Check if the item exists
      const item = await this.getItem("completed", id)

      if (!item) {
        console.log(`Download ${id} not found`)
        return
      }

      // Remove from cache
      const cache = await caches.open("downloads")
      await cache.delete(`/downloads/${id}`)

      // Remove from completed downloads
      await this.deleteItem("completed", id)

      // Emit event
      this.emit("download-deleted", { id })
    } catch (error) {
      console.error(`Failed to delete download ${id}:`, error)
      throw error
    }
  }

  /**
   * Get all pending downloads
   */
  async getPendingDownloads() {
    return this.getAllItems("pending")
  }

  /**
   * Get all completed downloads
   */
  async getCompletedDownloads() {
    return this.getAllItems("completed")
  }

  /**
   * Check if an item is downloaded
   * @param {string} id - ID of the item to check
   */
  async isDownloaded(id) {
    const item = await this.getItem("completed", id)
    return !!item
  }

  /**
   * Get download status for an item
   * @param {string} id - ID of the item to check
   */
  async getDownloadStatus(id) {
    // Check pending downloads
    const pendingItem = await this.getItem("pending", id)
    if (pendingItem) {
      return pendingItem.status
    }

    // Check completed downloads
    const completedItem = await this.getItem("completed", id)
    if (completedItem) {
      return "completed"
    }

    return "not-downloaded"
  }

  /**
   * Get an item from the database
   * @param {string} store - Store name ('pending' or 'completed')
   * @param {string} id - ID of the item to get
   */
  getItem(store, id) {
    return new Promise((resolve, reject) => {
      if (!this.db) {
        reject(new Error("Database not initialized"))
        return
      }

      const transaction = this.db.transaction(store, "readonly")
      const objectStore = transaction.objectStore(store)
      const request = objectStore.get(id)

      request.onsuccess = (event) => {
        resolve(event.target.result)
      }

      request.onerror = (event) => {
        console.error(`Failed to get item ${id} from ${store}:`, event.target.error)
        reject(event.target.error)
      }
    })
  }

  /**
   * Get all items from a store
   * @param {string} store - Store name ('pending' or 'completed')
   */
  getAllItems(store) {
    return new Promise((resolve, reject) => {
      if (!this.db) {
        reject(new Error("Database not initialized"))
        return
      }

      const transaction = this.db.transaction(store, "readonly")
      const objectStore = transaction.objectStore(store)
      const request = objectStore.getAll()

      request.onsuccess = (event) => {
        resolve(event.target.result)
      }

      request.onerror = (event) => {
        console.error(`Failed to get all items from ${store}:`, event.target.error)
        reject(event.target.error)
      }
    })
  }

  /**
   * Add an item to a store
   * @param {string} store - Store name ('pending' or 'completed')
   * @param {Object} item - Item to add
   */
  addItem(store, item) {
    return new Promise((resolve, reject) => {
      if (!this.db) {
        reject(new Error("Database not initialized"))
        return
      }

      const transaction = this.db.transaction(store, "readwrite")
      const objectStore = transaction.objectStore(store)
      const request = objectStore.add(item)

      request.onsuccess = (event) => {
        resolve(event.target.result)
      }

      request.onerror = (event) => {
        console.error(`Failed to add item to ${store}:`, event.target.error)
        reject(event.target.error)
      }
    })
  }

  /**
   * Update an item in a store
   * @param {string} store - Store name ('pending' or 'completed')
   * @param {Object} item - Item to update
   */
  updateItem(store, item) {
    return new Promise((resolve, reject) => {
      if (!this.db) {
        reject(new Error("Database not initialized"))
        return
      }

      const transaction = this.db.transaction(store, "readwrite")
      const objectStore = transaction.objectStore(store)
      const request = objectStore.put(item)

      request.onsuccess = (event) => {
        resolve(event.target.result)
      }

      request.onerror = (event) => {
        console.error(`Failed to update item in ${store}:`, event.target.error)
        reject(event.target.error)
      }
    })
  }

  /**
   * Delete an item from a store
   * @param {string} store - Store name ('pending' or 'completed')
   * @param {string} id - ID of the item to delete
   */
  deleteItem(store, id) {
    return new Promise((resolve, reject) => {
      if (!this.db) {
        reject(new Error("Database not initialized"))
        return
      }

      const transaction = this.db.transaction(store, "readwrite")
      const objectStore = transaction.objectStore(store)
      const request = objectStore.delete(id)

      request.onsuccess = (event) => {
        resolve()
      }

      request.onerror = (event) => {
        console.error(`Failed to delete item ${id} from ${store}:`, event.target.error)
        reject(event.target.error)
      }
    })
  }

  /**
   * Register an event listener
   * @param {string} event - Event name
   * @param {Function} callback - Callback function
   */
  on(event, callback) {
    if (!this.listeners[event]) {
      this.listeners[event] = []
    }

    this.listeners[event].push(callback)
  }

  /**
   * Remove an event listener
   * @param {string} event - Event name
   * @param {Function} callback - Callback function
   */
  off(event, callback) {
    if (!this.listeners[event]) {
      return
    }

    this.listeners[event] = this.listeners[event].filter((cb) => cb !== callback)
  }

  /**
   * Emit an event
   * @param {string} event - Event name
   * @param {Object} data - Event data
   */
  emit(event, data) {
    if (!this.listeners[event]) {
      return
    }

    this.listeners[event].forEach((callback) => {
      try {
        callback(data)
      } catch (error) {
        console.error(`Error in event listener for ${event}:`, error)
      }
    })
  }
}

// Create a singleton instance
const downloadManager = new DownloadManager()

// Export the instance
export default downloadManager

