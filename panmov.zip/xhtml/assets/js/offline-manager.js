/**
 * Offline Manager for Panyero
 * Handles offline content playback and management
 */

import downloadManager from "./download-manager.js"

class OfflineManager {
  constructor() {
    this.isInitialized = false
    this.listeners = {}

    // Initialize
    this.init()
  }

  /**
   * Initialize the offline manager
   */
  async init() {
    try {
      // Check if service worker is supported
      if ("serviceWorker" in navigator) {
        // Register service worker
        const registration = await navigator.serviceWorker.register("/service-worker.js")
        console.log("Service Worker registered with scope:", registration.scope)
      }

      this.isInitialized = true
      console.log("Offline Manager initialized successfully")
    } catch (error) {
      console.error("Failed to initialize Offline Manager:", error)
    }
  }

  /**
   * Check if a content is available offline
   * @param {string} id - Content ID
   */
  async isAvailableOffline(id) {
    return downloadManager.isDownloaded(id)
  }

  /**
   * Get all offline content
   */
  async getAllOfflineContent() {
    return downloadManager.getCompletedDownloads()
  }

  /**
   * Get offline content by type
   * @param {string} type - Content type (movie, tv, music)
   */
  async getOfflineContentByType(type) {
    const allContent = await downloadManager.getCompletedDownloads()
    return allContent.filter((item) => item.type === type)
  }

  /**
   * Play offline content
   * @param {string} id - Content ID
   */
  async playOfflineContent(id) {
    try {
      // Check if content is available offline
      const isAvailable = await this.isAvailableOffline(id)

      if (!isAvailable) {
        throw new Error("Content is not available offline")
      }

      // Get content details
      const content = await downloadManager.getItem("completed", id)

      // Redirect to appropriate player
      if (content.type === "tv") {
        window.location.href = `/offline-player.html?type=tv&id=${id}`
      } else if (content.type === "music") {
        window.location.href = `/offline-player.html?type=music&id=${id}`
      } else {
        window.location.href = `/offline-player.html?type=movie&id=${id}`
      }
    } catch (error) {
      console.error("Failed to play offline content:", error)
      throw error
    }
  }

  /**
   * Download content for offline viewing
   * @param {Object} content - Content to download
   */
  async downloadContent(content) {
    try {
      // Add to download queue
      return await downloadManager.addToQueue(content)
    } catch (error) {
      console.error("Failed to download content:", error)
      throw error
    }
  }

  /**
   * Delete offline content
   * @param {string} id - Content ID
   */
  async deleteOfflineContent(id) {
    try {
      await downloadManager.deleteDownload(id)
    } catch (error) {
      console.error("Failed to delete offline content:", error)
      throw error
    }
  }

  /**
   * Get download status
   * @param {string} id - Content ID
   */
  async getDownloadStatus(id) {
    return downloadManager.getDownloadStatus(id)
  }

  /**
   * Register an event listener
   * @param {string} event - Event name
   * @param {Function} callback - Callback function
   */
  on(event, callback) {
    // Pass through to download manager
    downloadManager.on(event, callback)
  }

  /**
   * Remove an event listener
   * @param {string} event - Event name
   * @param {Function} callback - Callback function
   */
  off(event, callback) {
    // Pass through to download manager
    downloadManager.off(event, callback)
  }
}

// Create a singleton instance
const offlineManager = new OfflineManager()

// Export the instance
export default offlineManager

